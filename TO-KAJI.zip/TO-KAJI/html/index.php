<?php
include 'common.php';
outputHeader("Home Page"); 
?>
    <!--header section starts here-->
    <section id="header">
        <!-- for responsive collapsing navigation-->
        <?php outputNavigation("index.php"); ?>
        <header id="intro">
           
            <!-- container-fluid class predefined bootstrap used for a specific section-->
            <div class="container-fluid ">Whats new!
                <!-- for signin link-->
                <div><a href="#down" id="logform2" class="regbutton" style="float: right;">Sign In?</a></div>
                <!-- container is predefined class of bootstrap-->
                <div class="container bg-light">

                    <div class="para">Whats new for today? Dont miss our new fish breeds. <br>
                        <a href="detailsanglefish.php" class="btn btn-danger">See more</a>
                    </div>
                </div>
            </div>
        </header>
    </section>
    <!--header section ends here-->


     <!-- Shopping section starts here-->
<section id="shopnow">
    <h2 class="logo-heading ">------------------------------------------SHOP
            NOW---------------------------------------</h2>
       
        <div class="shop ">
             <!-- Margin top for column -->
            <div class="card-columns border mt-3">

                <div class="card border">
                    <img src="../images/clownfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Clown fish</h4>
                        <p>Nice and small, this culture-bred clownfish is one of the most appreciated by aquarists and will generally bring a sparkle to kids’ eyes... </p>
                        <a href="detailsclownfish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>


                <div class="card border">
                    <img src="../images/hermitcrab.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Hermit crab</h4>
                        <p>ALGEA hermits are one of THE ESSENTIAL cuc for your aquarium to manage and control common algeas in your Marine aquarium and are Reef safe... </p>
                        <a href="detailshermitcrab.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/goldfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Gold fish</h4>
                        <p>Goldfish make an ideal pond filler and will mix with all other pond fish... </p>
                        <a href="detailsgoldfish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>


                <div class="card border">
                    <img src="../images/tangfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Tang fish</h4>
                        <p>Tangs are commonly referred to as Surgeonfish or Doctorfish, and make a wonderful addition to the reef or fish only aquarium. If m.. </p>
                        <a href="detailstangfish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>


                <div class="card border">
                    <img src="../images/noentetrafish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase"> Tetra fish</h4>
                        <p>The neon tetra is probably the most popular of all aquarium fish. It is reasonably hardy and easy to care for... </p>
                        <a href="detailsneontetrafish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>


                <div class="card border">
                    <img src="../images/gourami.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Gourami fish</h4>
                        <p>Gourami are very popular colourful fish take centre stage in many aquariums. There are many different colours in the Dwarf Gourami an.. </p>
                        <a href="detailsgouramifish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/fighterfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Fighter fish</h4>
                        <p>Fighting Fish, also known as Bettas, are a great addition to the aquarium but care needs to be taken. .. </p>
                        <a href="detailsfighterfish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/tigerbarb.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Tigerbarb fish</h4>
                        <p>Like many small shoaling fish, the barbs have a hierarchy system where each fish has a level of dominance. .. </p>
                        <a href="detailstigerbarb.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/rainbowfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">rainbow fish</h4>
                        <p>This little Rainbow fish is a peaceful shoaling fish that enjoys a well planted aquarium with free swimming areas... </p>
                        <a href="detailsrainbowfish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/anglefish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Angel fish</h4>
                        <p>Angelfish are a commonly kept popular aquarium fish. Their shape and variety of colours and patterns makes them.. </p>
                        <a href="detailsanglefish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/transparentfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Transparent fish</h4>
                        <p>They are hardy and mild tempered, and they are good tank mates for Neon Tetras and the other small Tropical Fish .. </p>
                        <a href="detailstransparent.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/zebrafish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Zebra fish</h4>
                        <p>The Zebra Danio is great starter fish and ideal for most community tanks. There are many varieties of this lovely fish and t.. </p>
                        <a href="detailszebrafish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>

                

                <div class="card border">
                    <img src="../images/bassletfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Basslet fish</h4>
                        <p>Reaching an average length of two inches in captivity, Basslets are colorful, hardy, and generally peaceful.. </p>
                        <a href="detailsbassletfish.php" class="btn btn-outline-danger">Read More..</a>
                        
                </div>


                <div class="card border">
                    <img src="../images/boxfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Box fish</h4>
                        <p>Boxfish has a skeleton which is fused to a solid structure and both are peaceful. It is im.. </p>
                        <a href="detailsboxfish.php" class="btn btn-outline-danger">Read More..</a>
                    
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/butterflyfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Butterfly fish</h4>
                        <p>This butterfly fish is generally introduced into reef aquariums to control the spread of cumbersome small anemones like Aiptasia. .. </p>
                        <a href="detailsbutterflyfish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>


                <div class="card border">
                    <img src="../images/cardinalfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Cardinal fish</h4>
                        <p>The average size of most Cardinalfish in captivity is two inches. These fish make great additions to a peaceful aquarium,.. </p>
                        <a href="detailscardinalfish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/chromisfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Chromis fish</h4>
                        <p>The Chromis is by far one of the most popular saltwater fish amongst fish keeping hobbyists.. </p>
                        <a href="detailschromisfish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/damselfish.png" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Damsel fish</h4>
                        <p>This damsel is a pretty, little species with colors ranging from apple green to light blue. Little sensitive to illnesses and unaggre.. </p>
                        <a href="detailsdamselfish.php" class="btn btn-outline-danger">Read More..</a>
                       
                    </div>
                </div>

            </div>


        </div>


    </section>
    <!-- section for best offer part-->
    <section class="bestoffer">
        <h2 class="logo-heading ">------------------------------------------Best
            Sellers--------------------------------------</h2>

        <div class="offer ">
            <div class="card-columns border mt-3">

                <div class="card border">
                    <img src="../images/clownfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Clown fish</h4>
                        <p>Nice and small, this culture-bred clownfish is one of the most appreciated by aquarists and will generally bring a sparkle to kids’ eyes... </p>
                        <a href="detailsclownfish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>


                <div class="card border">
                    <img src="../images/transparentfish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Transparent fish</h4>
                        <p>They are hardy and mild tempered, and they are good tank mates for Neon Tetras and the other small Tropical Fish.. </p>
                        <a href="detailstransparent.php" class="btn btn-outline-danger">Read More..</a>
                       
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/anglefish.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Angel fish</h4>
                        <p>Angelfish are a commonly kept popular aquarium fish. Their shape and variety of colours and patterns makes them.. </p>
                        <a href="detailsanglefish.php" class="btn btn-outline-danger">Read More..</a>
                        
                    </div>
                </div>



            </div>
        </div>

<!--- sectiomn for login box-->
    </section>
    <section class="loggs" style="background-color:  #6E6E6DFF;">
        <!--for alignment of the flexcontainers-->
        <div class="d-flex justify-content-around" style="display: flex;">
            <!-- margintop for row-->
            <div class="row mt-3">
                <!-- md used for tablets-->
                <div class="col-md-8 ">
        
                    <div class="card bg-light" style="width:800px;">
                        <div>
                            <!--div containing Forms for registration and paragraphs to provide feedback to the user-->
                            <div class="forms1" id="logform">
                                <fieldset>
                                    <legend id="down" class="forletters">Login here.</legend>
                                    <label for="Emailinput" class="forletters">EMAIL:&nbsp;&nbsp;&nbsp; </label><input
                                        type="email" id="Emailinput" placeholder="EMAIL" required
                                        style="width:300px"><span class="tick"></span>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <br><label for="Emailinput" class="forletters">PASSWORD:
                                        &nbsp;&nbsp;&nbsp;</label><input type="password" id="Passwordinput"
                                        placeholder="PASSWORD" required style="width:300px"><span class="tick"></span>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <button class="regbutton" onclick="validate()">LOGIN</button><br>
                                    <p class="forletters">Don't have an account?<a href="signup.php">click here</a></p>
                                   
                                    <p id="Confirm"></p>
                                </fieldset>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!-- sec tion for footer-->
<?php outputFooter(); ?>