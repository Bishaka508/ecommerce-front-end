<?php
include 'common.php';
outputHeader("Detailsfighterfish Pages"); 
?>
     <!--header section starts here-->
    <section id="header">
      <!-- for responsive collapsing navigation-->
        <?php outputNavigation("detailsfighterfish.php"); ?>
    </section>
    <section class="loggs" style="background-color:  #6E6E6DFF;">
        <!--for alignment of the flexcontainers-->
        <select>
        <option>Sort by </option>
        <option>High to low price</option>
        <option>Low to high price</option>

        
        </select>
        <div class="d-flex justify-content-around" style="display: flex;">
            <!-- margintop for row-->
            <div class="row mt-3">
                <!-- md used for tablets-->
                <div class="col-md-8 ">
        
                    <div class="card bg-light" style="width:800px;">
                    <img src="../images/fighterfish.jpg">
                   <div class ="col-lg-6 prod-des pl-md-5">
                   <h3> Fighter fish </h3>
                   <div class ="rating d-flex">
                   <p class ="text-left mr-4">
                   <a href="#" class="mr-2 text-dark">3.0</a>
                   <a href="#"><span class ="fas fa-star"></span></a>
                   <a href="#"><span class ="fas fa-star"></span></a>
                   <a href="#"><span class ="fas fa-star"></span></a>
                   </p>

                   </div>

                   <p class="price"><b>£20.00</b></p>
                   <p><b>COMMON NAME</b>: FIGHTER FISH </p>
                   <p><b>WATER TYPE</b>: SALT WATER </p>
                   <p><b>LIFE SPAN</b>: 4 TO 6 YEARS </p>
                   <p><b>WATER TEMPERATURE</b>: TROPICAL</p>
                   <p><b>DIFFICULT LEVEL</b>: BEGINNER </p>

                   <a href="basket.php" class="btn btn-outline-danger">Add to basket</a>
                   </div>
                     </div>
                        </div>
                          </div>
                             </div>

<div class="containerr">
       <div class="row">
           <div class="col-lg-12 text-center border rounded bg-light my-5 ">
               <h1> CUSTOMER ALSO LIKE</h1>
               </div>
               <div class="col-lg-8">
               <!-- table for basket box-->
               <table class="table">
                   <!-- aligning the the head in center-->
                   <thead class="text-center">
                       <tr>
                           <th scope="col" style="color:yellow;">SN.</th>
                           <th scope="col" style="color:yellow;">Similar product detail </th>
                           <th scope="col" style="color:yellow;">Price</th>
                           <th scope="col"></th>
                       </tr>
                   </thead>
                   <tbody class="text-center">
                     <tr>
                         <th scope="row" style="color:yellow;">1</th>
                         <td style="color:yellow;">Male fighter fish</td>
                         <td style="color:yellow;">£18</td>
                         <td><button class="btn btn-outline-light">ADD</button></td>

                     </tr> 
                     <tr>
                         <th scope="row" style="color:yellow;">2</th>
                         <td style="color:yellow;">Female fighter fish</td>
                         <td style="color:yellow;">£19</td>
                         <td><button class="btn btn-outline-light">ADD</button></td>
                     </tr> 
                     <tr>
                        <th scope="row" style="color:yellow;">3</th> 
                        <td style="color:yellow;">Size- 3-4 cm</td>
                        <td style="color:yellow;">£13.96</td>
                        <td><button class="btn btn-outline-light">ADD</button></td>
                     </tr>

                     <tr>
                        <th scope="row" style="color:yellow;">4</th> 
                        <td style="color:yellow;">Size- 5-6 cm </td>
                        <td style="color:yellow;">£25.54</td>
                        <td><button class="btn btn-outline-light">ADD</button></td>
                     </tr>
                     <tr>
                        <th scope="row" style="color:yellow;">4</th> 
                        <td style="color:yellow;">Black and white fish </td>
                        <td style="color:yellow;">£36.77</td>
                        <td><button class="btn btn-outline-light">ADD</button></td>
                     </tr>
                   </tbody>
               </table>
           </div>
           </div>
           </div>

          
                        </section>


    <?php outputFooter(); ?> 