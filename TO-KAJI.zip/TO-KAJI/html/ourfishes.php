<?php
include 'common.php';
outputHeader("Our Fishes Page"); 
?>

     <!--header section starts here-->
    <section id="header">
         <!-- for responsive collapsing navigation-->
        <?php outputNavigation("ourfishes.php"); ?>
   </section>  
   </body>
</html>   