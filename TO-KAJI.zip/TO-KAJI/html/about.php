<?php
include 'common.php';
outputHeader("Abour Us Page"); 
?>
    <!-- header section starts here-->
    <section id="header">
         <!-- for responsive collapsing navigation-->
        <?php outputNavigation("about.php"); ?>
   </section>
   <!--about section-->
   <section id="about">
       <div class="coverabout">ss</div>
          
      
   </section>

   <!-- footer section-->
  <?php outputFooter(); ?>  