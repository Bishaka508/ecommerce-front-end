<?php

//Ouputs the header for the page and opening body tag
function outputHeader($title){
    echo '<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/01d919c143.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/new.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <!--Google font-->
    <link href="https://fonts.googleapis.com/css2?family=Stylish&display=swap" rel="stylesheet">

    <!-- jQuery library -->
    <script src="../js/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="../js/bootstrap.min.js"></script>
    <title>'.$title.'</title>
</head>

<body>';
}


function outputNavigation($pageName){
    $linkNames = array("Home", "Our Fishes", "Aqua Food", "Sign Up","Basket","About Us");
    $linkAddresses = array("index.php", "#", "food.php", "signup.php","basket.php","about.php");
    $sublinks = array("",[
        [
            "name" => "Tetra",
            "page" => "detailsneontetrafish.php"
        ],
        [
            "name" => "Gold fish",
            "page" => "detailsgoldfish.php"
        ],
        [
            "name" => "chromis fish",
            "page" => "detailschromisfish.php"
        ],
        [
            "name" => "Transparent fish",
            "page" => "detailstransparent.php"
        ],
        [
            "name" => "Gourami",
            "page" => "detailsgouramifish.php"
        ],
        [
            "name" => "Butterfly Fish",
            "page" => "detailsbutterflyfish.php"
        ],
        [
            "name" => "Damsel fish",
            "page" => "detailsdamselfish.php"
        ],
        [
            "name" => "Fighter fish",
            "page" => "detailsfighterfish.php"
        ],
        [
            "name" => "Rainbow Fish",
            "page" => "detailsrainbowfish.php"
        ],
        [
            "name" => "Clown Fish",
            "page" => "detailsclownfish.php"
        ]
    ],
    "","","",""
    );
    echo '<nav class="navbar navbar-dark navbar-expand-lg">
           
            <a href="#" class="navbar-brand">
                <img src="../images/fish2.png">
                <span class="logo-heading">Aqua Middlesex</span>
            </a>
            <input placeholder="Search here" type="text">
            <button class="searchbutton"><i class="fas fa-search"></i></button>
            <!--data-toogle used for making meny drop down-->
            <!--data-target indicates which element to toggle-->
            <button class=navbar-toggler data-toggle="collapse" data-target="#navmenu">
                <!-- toggle icon in the right-->
                <span class="navbar-toggler-icon"></span></button>

            <div class="collapse navbar-collapse" id="navmenu">

                <!--ml-auto used for aligning navbar  items to right-->
                <ul class="navbar-nav ml-auto">
                    <!--marginleft auto-->
    ';
                    for($x = 0; $x < count($linkNames); $x++){
                        echo '<li';
                        if($linkAddresses[$x] == $pageName){
                            echo ' class="active" ';
                        }
                        echo '><a href="' . $linkAddresses[$x] . '" class="nav-link">' . $linkNames[$x] ."</a>";
                        

                        if ($sublinks[$x] != "") {
                            echo "<ul>";
                            foreach ($sublinks[$x] as $value) {
                                echo "<li><a href='{$value['page']}' class='nav-link bg-dark' >{$value['name']}</a></li>";
                            }
                            echo "</ul>";
                        }


                        echo '</li>';
                    }

    echo '
                    
                </ul>
            </div>
        </nav>';
}


//Outputs closing body tag and closing HTML tag
function outputFooter(){
    echo '<footer>
        <div class="foot">
        <div class="first-footer">
            <div class="forlinks">
                <ul>
                    <li class="icons"><a href="#"><i class="fab fa-instagram"></i></a></li>
                    <li class="icons"><a href="#"><i class="fab fa-facebook"></i></a></li>
                    <li class="icons"><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li class="icons"><a href="#"><i class="far fa-envelope"></i></a></li>
                </ul>
            </div>
 
            <div class="infolink">
                <ul>
                   <li class="icons2"><a href="index.php">Home</a></li>
                   <li class="icons2"><a href="food.php">Foods</a></li>
                   <li class="icons2"><a href="about.php">About</a></li>
                   <li class="icons2"><a href="#">contact us</a></li>
                </ul>
            </div>
        </div>
 
        <div class="last-footer">
            Copyright &copy; Web application. All Rights Reserved
        </div>
        </div>
    </footer>

</body>


</html>';
}

