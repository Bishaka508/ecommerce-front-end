<?php
include 'common.php';
outputHeader("Food Page"); 
?>
      <!--header section starts here-->
    <section id="header">
         <!-- for responsive collapsing navigation-->
        <?php outputNavigation("food.php"); ?>
    </section>




   <!-- shopping of foods section start here-->

    <section id="shopnow">
        
        <div class="shop " style="display: flex; ">
            
            <div class="card-columns border mt-3">

                <div class="card border">
                    <img src="../images/pellet.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">AQUAFIN 9,Micro pallet</h4>
                        
                        <a href="basket.html" class="btn btn-outline-danger">Add to basket</a>
                    </div>
                </div>


                <div class="card border">
                    <img src="../images/pellet2.png" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Taiyo, Micro pellet</h4>
                        
                        <a href="basket.php" class="btn btn-outline-danger">Add to basket</a>
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/pellet3.jpeg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Hikari, micro pellets</h4>
                        <a href="basket.php" class="btn btn-outline-danger">Add to basket</a>
                    </div>
                </div>


                <div class="card border">
                    <img src="../images/tropical_flake2.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Fluval,Tropical fish flakes</h4>
                        <a href="basket.php" class="btn btn-outline-danger">Add to basket</a>
                    </div>
                </div>


                <div class="card border">
                    <img src="../images/tropical_flake3.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase"> Aqueon, tropical flakes</h4>
                        <a href="basket.php" class="btn btn-outline-danger">Add to basket</a>
                    </div>
                </div>


                <div class="card border">
                    <img src="../images/tropical_flakes.jpeg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Tetra, tropical flakes</h4>
                        <a href="basket.php" class="btn btn-outline-danger">Add to basket</a>
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/tropical_flake4.jpeg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">King british,tropical fish flake</h4>
                        <a href="basket.php" class="btn btn-outline-danger">Add to basket</a>
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/pellet5.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">TetraCichlid, floating pellets</h4>
                        <a href="basket.php" class="btn btn-outline-danger">Add to basket</a>
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/pellet6.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Tropical,Cichlid carnivore pellet</h4>
                        <a href="basket.php" class="btn btn-outline-danger">Add to basket</a>
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/pellet7.jpg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Tropical,Cichlid herbivore pellet</h4>
                        <a href="basket.php" class="btn btn-outline-danger">Add to basket</a>
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/food1.jpeg" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Aquatic turtule food</h4>
                        <a href="basket.php" class="btn btn-outline-danger">Add to basket</a>
                    </div>
                </div>

                <div class="card border">
                    <img src="../images/food2.png" class="card-img-top">
                    <div class="card-body">
                        <h4 class="text-uppercase">Gardeners, premium tropical flakes</h4>
                        <a href="basket.php" class="btn btn-outline-danger">Add to basket</a>
                    </div>
                </div>

            </div>


        </div>

        
    </section>
    <!-- footer section starts here-->
    <?php outputFooter(); ?>