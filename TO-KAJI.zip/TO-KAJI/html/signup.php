<?php
include 'common.php';
outputHeader("Signup Pages"); 
?>
     <!--header section starts here-->
    <section id="header">
      <!-- for responsive collapsing navigation-->
        <?php outputNavigation("signup.php"); ?>
    </section>
<section class="regs " > 
    <!-- to change the alignment of flex items-->  
 <div class="d-flex justify-content-around" style="display: flex;">   

       
    <div class="row mt-3">
               
        <div class="col-md-14 border">
                <!-- bootstrap baxkground colour-->
                <div class="card bg-light">
                   
                        <div >
                            <!--div containing Forms for registration and paragraphs to provide feedback to the user-->
                            <div class="forms2" >
                                <fieldset>
                                    <legend class="logo-heading" style="color:black;">Personal Information :</legend>
                                    <br>
                                    <label for="Fnameinput" class="forletters"> FIRST NAME: </label><input type="text" id="Fnameinput"
                                        placeholder="FIRST NAME" required>
                                    <p id="feedfname" style="color:red"></p>

                                    <label for="Lnameinput" class="forletters">LAST NAME: </label><input type="text" id="Lnameinput"
                                        placeholder="LAST NAME" required>
                                    <p id="feedlname" style="color:red"></p>

                                    <label for="Emailinput" class="forletters">EMAIL: </label><input type="email" id="Emailinput"
                                        placeholder="EMAIL" required>
                                    <p id="feedemail" style="color:red"></p>

                                    <label for="Passwordinput" class="forletters">PASSWORD: </label><input type="password"
                                        id="Passwordinput" placeholder="PASSWORD" required>
                                    <p id="feedpass" style="color:red"></p>

                                    <label for="Addressinput" class="forletters">ADDRESS: </label><input type="text" id="Addressinput"
                                        placeholder="ADDRESS" required>
                                    <p id="feedaddress" style="color:red"></p>

                                    <label for="Phoneinput" class="forletters">PHONE: </label><input type="text" id="Phoneinput"
                                        placeholder="PHONE" required>
                                    <p id="feedphone" style="color:red"></p>

                                    <button class="regbutton" onclick="storeUser()">REGISTER</button>
                                    <p id="feeds" style="color:green"></p>
                                </fieldset>
                            </div>
                        </div>
                    </div>
            
                </div>
         </div>
       </div>
       
        </div> 
</section> 
<!-- footer section starts here -->
<?php outputFooter(); ?>