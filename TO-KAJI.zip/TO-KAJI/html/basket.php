<?php
include 'common.php';
outputHeader("Basket Pages"); 
?>
     <!--header section starts here-->
    <section id="header">
      <!-- for responsive collapsing navigation-->
        <?php outputNavigation("detail.php"); ?>
    </section>
   </section>  
<!-- the main basket section starts here-->
   <div class="containerr">
       <div class="row">
           <div class="col-lg-12 text-center border rounded bg-light my-5 ">
               <h1> My Basket</h1>
           </div>
           <!-- boostrap-->
           <div class="col-lg-8">
               <!-- table for basket box-->
               <table class="table">
                   <!-- aligning the the head in center-->
                   <thead class="text-center">
                       <tr>
                           <th scope="col">SN.</th>
                           <th scope="col">Product Name</th>
                           <th scope="col"> Price</th>
                           <th scope="col">Quantity</th>
                           <th scope="col"></th>
                       </tr>
                   </thead>
                   <tbody class="text-center">
                     <tr>
                         <th scope="row">1</th>
                         <td>Clown fish</td>
                         <td>£12</td>
                         <td><input type="number" value="1"></td>
                         <td><button class="btn btn-outline-danger">Delete</button></td>

                     </tr> 
                     <tr>
                         <th scope="row">2</th>
                         <td>Gold fish</td>
                         <td>£15</td>
                         <td><input type="number" value="1"></td>
                         <td><button class="btn btn-outline-danger">Delete</button></td>
                     </tr> 
                     <tr>
                        <th scope="row">3</th> 
                        <td>Ghost fish</td>
                        <td>£18</td>
                        <td><input type="number" value="1"></td>
                        <td><button class="btn btn-outline-danger">Delete</button></td>
                     </tr>
                   </tbody>
               </table>
           </div>
        
       </div>
       <div>
        <button class="btn btn-outline-danger ">Proceed to checkout</button>
       </div>
   </div>
   